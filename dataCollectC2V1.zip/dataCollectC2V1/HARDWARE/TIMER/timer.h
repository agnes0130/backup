#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"

void Timerx_Init(void); 
 
#endif
